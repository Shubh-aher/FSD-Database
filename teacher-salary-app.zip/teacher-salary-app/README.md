# Teacher Salary App

This project is a Node.js application that connects to a MySQL database to fetch teacher data based on a salary condition.

## Setup

1. Clone the repository
2. Run `npm install` to install dependencies
3. Create a `.env` file with your database credentials
4. Run `npm start` to start the server

## API Endpoint

- `GET /api/teachers`: Fetch teachers with salary greater than 20,000

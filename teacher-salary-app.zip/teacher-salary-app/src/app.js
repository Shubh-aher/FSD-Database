const express = require('express');
const dotenv = require('dotenv');
const teacherRoutes = require('./routes/teacherRoutes');

// Load environment variables from .env file
dotenv.config();

const app = express();

// Middleware for JSON response
app.use(express.json());

// Use the teacher routes
app.use('/api', teacherRoutes);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

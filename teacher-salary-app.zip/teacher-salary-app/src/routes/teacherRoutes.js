const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacherController');

// Define the route for getting teachers with a salary > 20,000
router.get('/teachers', teacherController.getTeachers);

module.exports = router;

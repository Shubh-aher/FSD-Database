require('dotenv').config(); // <-- Load .env variables
const mysql = require('mysql2');

// Create a connection pool (good for performance)
const pool = mysql.createPool({
  host: process.env.DB_HOST,  // Use environment variables for sensitive data
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});
console.log('DB_USER:', process.env.DB_USER);

module.exports = pool.promise();  // Use promise-based queries

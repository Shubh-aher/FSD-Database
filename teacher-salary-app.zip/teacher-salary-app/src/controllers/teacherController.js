const db = require('../database/db');

const getTeachers = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM Teacher WHERE salary > 20000');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getTeachers,
};
